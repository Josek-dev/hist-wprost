<div class="userInfo">
<div><label>User Type:</label>
<select name="userType[]" class="userType">
</select>
</div>
<div><label>Date of Birth:</label><input type="text" name="dateAry[]" class="userDOB" />
</div>
</div>