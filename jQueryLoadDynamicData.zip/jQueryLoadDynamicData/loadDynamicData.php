<?php
$listOptions = '';
$userType = array("visiter","member", "admin");
foreach($userType as $k) {
$listOptions .= "<option value='" . $k . "'>" . $k . "</option>";
}
?>
<html>
<head>
<title>Load Dynamic Data using jQuery</title>
<link rel="stylesheet" href="styles.css" />
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<script>
function setDynamicUI(view) {
$("<div>").load(view, function() {
	$("#target").append($(this).html());
	$(".userType").html(<?php echo json_encode($listOptions); ?>); 
	$('.userDOB').datepicker({
	  changeMonth: true,
	  changeYear: true
	});
});
}
$( document ).ready(setDynamicUI("userInfo.php"));
</script>
</head>
<body>
<div id="target"></div>
<div class="moreUser" align="right"><img src="moreUser.png" title="More User" alt="More User"  onClick="setDynamicUI('userInfo.php');" /></div>
</body>
</html>